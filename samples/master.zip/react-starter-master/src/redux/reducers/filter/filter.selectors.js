export const getFilter = (state) => state.filter
