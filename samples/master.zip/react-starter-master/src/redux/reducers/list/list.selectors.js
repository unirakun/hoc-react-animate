export const getList = (state) => state.list
