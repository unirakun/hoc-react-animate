export default from './App'
